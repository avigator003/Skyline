module.exports = {
    'secret': 'sa3fXr8yb5AiMiK',
    'mongodbUri': "mongodb+srv://admin:Xxf9bGiubfgx9NV9@cluster0.njgjj.mongodb.net/sky?retryWrites=true&w=majority"
}
// 'mongodbUri': 'mongodb+srv://anas:3125mhow@cluster0-rhfrl.mongodb.net/lawyer?retryWrites=true&w=majority'
